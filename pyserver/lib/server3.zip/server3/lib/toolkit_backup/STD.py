import numpy as np


def toolkit_std(arr):
    """STD"""
    np_temp = np.array(arr)
    return np.std(np_temp)

# toolkit_std = toolkit_std(input_data)
