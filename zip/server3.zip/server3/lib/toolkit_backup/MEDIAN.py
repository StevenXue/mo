import numpy as np


def toolkit_median(arr):
    """median"""
    return np.median(np.array(arr))

# toolkit_result_median = toolkit_median(input_data)
