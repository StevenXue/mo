import numpy as np


def toolkit_average(arr):
    """average"""
    return np.average(np.array(arr))

# toolkit_result_avg = toolkit_average(input_data)
